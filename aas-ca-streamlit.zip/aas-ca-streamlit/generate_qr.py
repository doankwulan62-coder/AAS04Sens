"""Buat QR code dari URL aplikasi.

Pemakaian:
    python generate_qr.py https://gangguan-ca-aas.streamlit.app
    python generate_qr.py https://github.com/USERNAME/aas-ca-streamlit -o qr_github.png
"""
import argparse

import qrcode

p = argparse.ArgumentParser()
p.add_argument("url", nargs="?", default="https://gangguan-ca-aas.streamlit.app")
p.add_argument("-o", "--output", default="qr_code.png")
a = p.parse_args()

qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=12, border=4)
qr.add_data(a.url)
qr.make(fit=True)
qr.make_image(fill_color="black", back_color="white").save(a.output)
print(f"QR tersimpan: {a.output}  ->  {a.url}")
