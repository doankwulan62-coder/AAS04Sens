# 🔥 Gangguan Analisis Ca pada Spektrofotometri Serapan Atom-Nyala

Digitalisasi percobaan gangguan kalsium pada AAS nyala (Ca 422,7 nm, lampu katoda
berongga Ca, nyala udara–asetilen): model 3D instrumen, kurva kalibrasi, Ca terukur
pada 9 larutan uji, pengaruh sulfat/fosfat + agen pelepas, dan laporan praktikum otomatis.

## Struktur
```
app.py            # aplikasi Streamlit
aas_ca.html       # aplikasi interaktif (HTML + three.js)
generate_qr.py    # pembuat QR dari terminal
qr_code.png       # QR code aplikasi
requirements.txt
.streamlit/config.toml
```

## Jalankan lokal
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy (Streamlit Community Cloud)
1. Upload repo ke GitHub (lihat langkah di bawah).
2. Buka https://share.streamlit.io → **Create app** → pilih repo, branch `main`, file `app.py`.
3. Di **Advanced settings → App URL**, isi subdomain `gangguan-ca-aas`
   agar URL sesuai QR: `https://gangguan-ca-aas.streamlit.app`.
4. Jika URL berbeda, buat ulang QR: `python generate_qr.py <URL-baru>`.

## Upload ke GitHub
```bash
git init
git add .
git commit -m "Aplikasi AAS Ca - Streamlit"
git branch -M main
git remote add origin https://github.com/USERNAME/aas-ca-streamlit.git
git push -u origin main
```
